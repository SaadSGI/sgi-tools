# SGI Tools - By Mohd Saad Iraqi

All-in-one web tools created by Mohd Saad Iraqi:
- Watermark Remover
- Passport Size Photo Maker
- Basic Video Editor
- Templates Download

Live: https://saadsgi.github.io/sgi-tools/
