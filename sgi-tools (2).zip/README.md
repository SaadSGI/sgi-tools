# SGI Tools by Mohd Saad Iraqi

This is a personal website offering:
- 🖼️ Watermark Remover
- 🪪 Passport Size Photo Maker
- 🎬 Basic Video Editor
- 📂 Templates Downloader

Live site: https://saadsgi.github.io/sgi-tools/
